﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    //Represents an order sent by a restaurant to the company. Contains the restaurant name, the total quantity and the list of special orders.
    public class RestaurantOrder
    {
        private Restaurant restaurant;
        private List<MealTypeOrder> orders;
        private int quantity;

        //Constructor using the restaurant name. Initializes the list of orders
        public RestaurantOrder(Restaurant pRestaurant)
        {
            restaurant = pRestaurant;
            orders = new List<MealTypeOrder>(); 
        }

        //Adds a special order to the list
        public void addOrder(MealTypeOrder pOrder)
        {
            orders.Add(pOrder);
        }

        //Increases the number of orders by a given quantity
        public void addQuantity(int pQuantity)
        {
            quantity += pQuantity;
        }

        // returns the restaurant name
        public Restaurant getRestaurant()
        {
            return restaurant;
        }

        //Returns the list of special orders
        public List<MealTypeOrder> getOrders()
        {
            return orders;
        }

        //Returns the total Quantity
        public int getQuantity()
        {
            return quantity;
        }
    }
}
