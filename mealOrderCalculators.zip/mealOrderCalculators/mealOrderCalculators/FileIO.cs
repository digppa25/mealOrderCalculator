﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    public class FileIO
    {
        //Reads each line of a file as an element of an Array
        public string[] readFile(string fileName)
        {
            string[] lines = System.IO.File.ReadAllLines(fileName);
            return lines;
        }

        //writes each element of an Array as a line in a file
        public void writeFile(string[] content, string fileName)
        {
            System.IO.File.WriteAllLines(makeFileName(fileName), content);
        }

        //creates the output filename by adding .out to the input file name
        public static string makeFileName(String fileName)
        {
            string newFileName = fileName + ".out";
            return newFileName;
        }
    }
}
