﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    //Represents a Lunch order placed by a company. Consists of a list of special orders (MealTypeOrders), and a total quantity
    public class Order
    {
        private List<MealTypeOrder> orders;
        private int totalOrders;

        //Constructor takes both parameters and sets them
        public Order(List<MealTypeOrder> pOrders, int pTotalOrders)  
        {
            orders = pOrders;
            totalOrders = pTotalOrders;
        }

        //Constructor using and List<string>. Conatins the word Order followed by the total orders and then one entry for each mealTypeOrder Tuple
        public Order(List<string> input) 
        {
            int begin = input.IndexOf("Order");
            orders = new List<MealTypeOrder>();
            string[] total = input.ElementAt(begin + 1).Split(':');
            if (total[0] == "Total")
            {
                totalOrders = Int32.Parse(total[1]);
            }

            foreach (string s in input.Skip(begin+2))
            {
                string[] rOrder = s.Split(':');
                MealTypeOrder meal = new MealTypeOrder(rOrder[0], Int32.Parse(rOrder[1]));
                orders.Add(meal);
            }
        }       

        //Returns the total Orders
        public int getTotalOrders()
        {
            return totalOrders;
        }    

        //Returns the list of tuples for the special orders
        public List<MealTypeOrder> getOrders()
        {
            return orders;
        }
    }
}
