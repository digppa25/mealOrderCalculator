﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    class Program
    {
        //Main program, reads the input, processes it and writes the results onto a new text file.
        static void Main(string[] args)
        {
            OrderCalculator ordercalculator = new OrderCalculator(args[0]);
            ordercalculator.parseInput();
            ordercalculator.calculateResult();
            ordercalculator.printResult();
        }
    }
}
