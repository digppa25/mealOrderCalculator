﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    //Contains the methods that parse the input. Calculate the result and wirte it onto a text file
    //It contains the order, and retsaurants needed for the calculations as well as the result 
    public class OrderCalculator
    {
        private Order order;
        private List<Restaurant> restaurants;
        private List<RestaurantOrder> result;
        private string filename;

        //Empty Constructor
        public OrderCalculator() { }

        //Constructor takes all parameteres needed for the calculations
        public OrderCalculator(Order pOrder, List<Restaurant> pRestaurants)
        {
            order = pOrder;
            restaurants = pRestaurants;
            result = new List<RestaurantOrder>();
        }

        //Constructor, takes a filename that contains all the input information
        public OrderCalculator(string fileName)
        {
            result = new List<RestaurantOrder>();
            filename = fileName;
        }

        //returns the result
        public List<RestaurantOrder> getResult()
        {
            return result;
        }

        //reads the input file and creates the Order, and Restaurant objects that correspond
        public void parseInput()
        {
            FileIO fileio = new FileIO();
            List<string> input = fileio.readFile(filename).ToList<string>();
            order = new Order(getFirstPart(input));            
            getRestaurants(getRestOfParts(input));
        }

        //Uses the Objects and restaurant objects to calculate the result
        public void calculateResult()
        {
            restaurants.Sort();
            int mealTypeRemaining;
            int totalRemaining = order.getTotalOrders();

            //loop through special orders ordered by the comapny
            foreach (MealTypeOrder mealTypeOrder in order.getOrders())
            {
                mealTypeRemaining = mealTypeOrder.getQuantity();
                //loop trhrough restaurants
                foreach (Restaurant restaurant in restaurants)
                {
                    if (mealTypeRemaining == 0)
                    {
                        break;
                    }
                    //loop through each menu to check special order availability
                    foreach (MealTypeOrder restaurantOrder in restaurant.getOrders())
                    {
                        if (mealTypeOrder.getMealType() == restaurantOrder.getMealType())
                        {
                            if (mealTypeRemaining <= restaurantOrder.getQuantity())
                            {
                                MealTypeOrder newOrder = new MealTypeOrder(mealTypeOrder.getMealType(), mealTypeRemaining);
                                getRestaurantOrder(restaurant, newOrder);
                                restaurant.takeOrder(mealTypeRemaining);
                                totalRemaining -= mealTypeRemaining;
                                mealTypeRemaining = 0;                                
                            }
                            else
                            {
                                MealTypeOrder newOrder = new MealTypeOrder(mealTypeOrder.getMealType(), restaurantOrder.getQuantity());
                                getRestaurantOrder(restaurant, newOrder);
                                restaurant.takeOrder(restaurantOrder.getQuantity());
                                mealTypeRemaining -= restaurantOrder.getQuantity();
                                totalRemaining -= restaurantOrder.getQuantity();
                            }
                            break;
                        }
                    }
                }                
            }

            //loop through restaurants to provide remaining orders
            foreach (Restaurant restaurant in restaurants)
            {
                if (totalRemaining == 0)
                {
                    break;
                }
                if (totalRemaining <= restaurant.getRemainingOrders())
                {
                    getRestaurantOrder(restaurant, totalRemaining);
                    restaurant.takeOrder(totalRemaining);
                    totalRemaining = 0;
                }
                else
                {
                    getRestaurantOrder(restaurant, restaurant.getRemainingOrders());
                    totalRemaining -= restaurant.getRemainingOrders();
                    restaurant.takeOrder(restaurant.getRemainingOrders());                    
                }
            }
            
        }

        //Takes the result parameter and creates a string[] to print into the output text file
        public void printResult()
        {
            List<string> print = new List<string>();
            foreach (RestaurantOrder restaurantOrder in result)
            {
                print.Add(restaurantOrder.getRestaurant().getName());
                foreach (MealTypeOrder mealTypeOrder in restaurantOrder.getOrders())
                {
                    print.Add(mealTypeOrder.getMealType() + " " + mealTypeOrder.getQuantity().ToString());
                }
                print.Add("Others " + restaurantOrder.getQuantity().ToString());
                print.Add("");
            }            
            string[] printArray = print.ToArray();
            FileIO fileio = new FileIO();
            fileio.writeFile(printArray, filename);
        }

        //Gets every item of a list after the first occurrence of an empty string ("")
        public static List<string> getRestOfParts(List<string> input)
        {
            return input.GetRange(input.IndexOf("") + 1, input.Count - input.IndexOf("")-1);
        }

        //Gets every item of a list before the first occurrence of an empty string ("")
        public static List<string> getFirstPart(List<string> input)
        {
            return input.GetRange(0, input.IndexOf(""));
        }

        //Iterates throught the list of restaurants to create each restaurant object
        public void getRestaurants(List<string> restaurantsInput)
        {
            restaurants = new List<Restaurant>();
            while (restaurantsInput.Count>0)
            {                
                if (restaurantsInput.IndexOf("") != -1)
                {
                    Restaurant restaurant = new Restaurant(getFirstPart(restaurantsInput));
                    restaurants.Add(restaurant);
                    restaurantsInput = getRestOfParts(restaurantsInput);                    
                }
                else
                {
                    Restaurant restaurant = new Restaurant(restaurantsInput);
                    restaurants.Add(restaurant);
                    break;
                }                
            } 
        }       

        //Adds a special order to the result. If the restaurant already exists in the result, it adds it to that object
        public void getRestaurantOrder(Restaurant restaurant, MealTypeOrder mealTypeOrder)
        {
            bool found = false;
            foreach (RestaurantOrder restaurantOrder in result)
            {
                if (restaurant.getName() == restaurantOrder.getRestaurant().getName())
                {
                    restaurantOrder.addOrder(mealTypeOrder);
                    found = true;
                    break;                   
                }
            }
            if (!found)
            {
                RestaurantOrder newOrder = new RestaurantOrder(restaurant);
                newOrder.addOrder(mealTypeOrder);
                result.Add(newOrder);
            }
        }

        //Adds a regular order to the result. If the restaurant already exists in the result, it adds it to that object
        public void getRestaurantOrder(Restaurant restaurant, int quantity)
        {
            bool found = false;
            foreach (RestaurantOrder restaurantOrder in result)
            {
                if (restaurant.getName() == restaurantOrder.getRestaurant().getName())
                {
                    restaurantOrder.addQuantity(quantity);
                    found = true;
                    break;
                }

            }
            if (!found)
            {
                RestaurantOrder newOrder = new RestaurantOrder(restaurant);
                newOrder.addQuantity(quantity);
                result.Add(newOrder);
            }
        }

        // Returns the order
        public Order getOrder()
        {
            return order;
        }

        //returns de list of restaurants
        public List<Restaurant> getRestaurants()
        {
            return restaurants;
        }       
    }
}
