﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    // Represents the available menu of a restaurant. 
    // Contains a name, a rating, a number of available orders and special orders, and a parameter to track the orders taken
    // Implements the IComparable Interface in order to be able to sort the restaurants by Rating
    public class Restaurant:IComparable<Restaurant>
    {
        string name;
        private List<MealTypeOrder> orders;
        private double rating;
        private int availableOrders;
        private int remainingOrders;

        //Constructor for the class. Takes four parameters and sets them
        public Restaurant(string pName, List<MealTypeOrder> pOrders, double pRating, int pAvailableOrders)       
        {
            name = pName;
            orders = pOrders;
            rating = pRating;
            availableOrders = pAvailableOrders;
            remainingOrders = pAvailableOrders;
        }

        //Constructor for the class. uses a List<string> as input. Contains the restaurant name, rating, total orders and an entry for each meal type order. Restaurants are separated by empty string "" entries.
        public Restaurant(List<string> input)
        {
            orders = new List<MealTypeOrder>();
            name = input.ElementAt(0);            

            string[] rRating = input.ElementAt(1).Split(':');
            if (rRating[0] == "Rating")
            {
                string[] fraction = rRating[1].Split('/');
                rating = Double.Parse(fraction[0])/ Double.Parse(fraction[1]);
            }

            string[] rTotal = input.ElementAt(2).Split(':');
            if (rTotal[0] == "Total")
            {
                availableOrders = Int32.Parse(rTotal[1]);
                remainingOrders = availableOrders;
            }
            
            foreach (string s in input.Skip(3))
            {
                string[] rOrder = s.Split(':');
                MealTypeOrder meal = new MealTypeOrder(rOrder[0], Int32.Parse(rOrder[1]));
                orders.Add(meal);
            }
        }

        //returns the special orders.
        public List<MealTypeOrder> getOrders()
        {
            return orders;
        }

        //returns the rating.
        public double getRating()
        {
            return rating;
        }

        //retruns the available orders.
        public int getAvailableOrders()
        {
            return availableOrders;
        }

        //returns the remaining orders.
        public int getRemainingOrders()
        {
            return remainingOrders;
        }

        //returns the name
        public string getName()
        {
            return name;
        }

        //Updates the remaining orders when an order is taken
        public void takeOrder(int quantity)
        {
            remainingOrders -= quantity;
        }

        //Sets the sorting criteria. Restaurants are sorted first by rating and second by total meals available
        public int CompareTo(Restaurant other)
        {
            if (this.getRating() < other.getRating()) return 1;
            else if (this.getRating() > other.getRating()) return -1;
            else
            {
                if (this.getAvailableOrders() < other.getAvailableOrders()) return 1;
                else if (this.getAvailableOrders() > other.getAvailableOrders()) return -1;
                else return 0;
            }
                
                
        }
    }
}
