﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mealOrderCalculators
{
    //Represents a tuple consisting of <MealType,Quantity>
    public class MealTypeOrder
    {
        private string mealType; 
        private int quantity;

        //Constructor for the class, takes both parameters
        public MealTypeOrder(string pMealType, int pQuantity)
        {
            mealType = pMealType;
            quantity = pQuantity;
        }

        //Returns the Meal Type
        public string getMealType()
        {
            return mealType;
        }

        //Returns the quantity
        public int getQuantity()
        {
            return quantity;
        }
    }    
}
