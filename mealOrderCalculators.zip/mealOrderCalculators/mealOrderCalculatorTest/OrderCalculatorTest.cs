﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Cryptography;
using System.IO;
using mealOrderCalculators;

namespace mealOrderCalculatorTest
{
    //Unit Testing for OrderCalculator class
    [TestClass]
    public class OrderCalculatorTest
    {
        //Tests the parseInput method. Provides a file to read and checks for the creation of all the expected objects
        [TestMethod]
        public void parseInputTest()
        {
            OrderCalculator orderCalculator = new OrderCalculator(@"..\..\..\mealOrderCalculators\test.txt");
            orderCalculator.parseInput();
            Assert.AreEqual(50, orderCalculator.getOrder().getTotalOrders());
            Assert.AreEqual(5, orderCalculator.getOrder().getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", orderCalculator.getOrder().getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(7, orderCalculator.getOrder().getOrders().ElementAt(1).getQuantity());
            Assert.AreEqual("Gluten free", orderCalculator.getOrder().getOrders().ElementAt(1).getMealType());

            Assert.AreEqual("Restaurant A", orderCalculator.getRestaurants().ElementAt(0).getName());
            Assert.AreEqual(1, orderCalculator.getRestaurants().ElementAt(0).getRating());
            Assert.AreEqual(40, orderCalculator.getRestaurants().ElementAt(0).getAvailableOrders());
            Assert.AreEqual(40, orderCalculator.getRestaurants().ElementAt(0).getRemainingOrders());
            Assert.AreEqual(4, orderCalculator.getRestaurants().ElementAt(0).getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", orderCalculator.getRestaurants().ElementAt(0).getOrders().ElementAt(0).getMealType());

            Assert.AreEqual("Restaurant B", orderCalculator.getRestaurants().ElementAt(1).getName());
            Assert.AreEqual(0.6, orderCalculator.getRestaurants().ElementAt(1).getRating());
            Assert.AreEqual(100, orderCalculator.getRestaurants().ElementAt(1).getAvailableOrders());
            Assert.AreEqual(100, orderCalculator.getRestaurants().ElementAt(1).getRemainingOrders());
            Assert.AreEqual(20, orderCalculator.getRestaurants().ElementAt(1).getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", orderCalculator.getRestaurants().ElementAt(1).getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(20, orderCalculator.getRestaurants().ElementAt(1).getOrders().ElementAt(1).getQuantity());
            Assert.AreEqual("Gluten free", orderCalculator.getRestaurants().ElementAt(1).getOrders().ElementAt(1).getMealType());
        }

        //Tests the calculate result method. Uses one order and two restaurants to check if the expected result is reached
        [TestMethod]
        public void calculateResultTest()
        {
            List<string> inputOrder = new List<string>() { "Order", "Total:50", "Vegetarian:5", "Gluten free:7" };
            Order order1 = new Order(inputOrder);

            List<string> inputRestauranA = new List<string>() { "Restaurant A", "Rating:5/5", "Total:40", "Vegetarian:4" };
            Restaurant restaurantA = new Restaurant(inputRestauranA);
            List<string> inputRestauranB = new List<string>() { "Restaurant B", "Rating:3/5", "Total:100", "Vegetarian:20", "Gluten free:10" };
            Restaurant restaurantB = new Restaurant(inputRestauranB);
            List<Restaurant> restaurants = new List<Restaurant>() { restaurantA, restaurantB };

            OrderCalculator orderCalculator = new OrderCalculator(order1, restaurants);
            orderCalculator.calculateResult();

            Assert.AreEqual("Restaurant A", orderCalculator.getResult().ElementAt(0).getRestaurant().getName());
            Assert.AreEqual(36, orderCalculator.getResult().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", orderCalculator.getResult().ElementAt(0).getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(4, orderCalculator.getResult().ElementAt(0).getOrders().ElementAt(0).getQuantity());

            Assert.AreEqual("Restaurant B", orderCalculator.getResult().ElementAt(1).getRestaurant().getName());
            Assert.AreEqual(2, orderCalculator.getResult().ElementAt(1).getQuantity());
            Assert.AreEqual("Vegetarian", orderCalculator.getResult().ElementAt(1).getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(1, orderCalculator.getResult().ElementAt(1).getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Gluten free", orderCalculator.getResult().ElementAt(1).getOrders().ElementAt(1).getMealType());
            Assert.AreEqual(7, orderCalculator.getResult().ElementAt(1).getOrders().ElementAt(1).getQuantity());


        }

        //Tests the getFristPart method
        [TestMethod]
        public void getFirstPartTest()
        {

            List<string> test1 = new List<string>() { "1", "", "3", "4", "5" };
            List<string> test2 = new List<string>() { "1", "2", "3", "4", "" };
            List<string> test3 = new List<string>() { "", "2", "3", "4", "5" };
            List<string> test4 = new List<string>() { "1", "", "3", "", "5" };

            CollectionAssert.AreEqual(new List<string>() { "1" }, OrderCalculator.getFirstPart(test1));
            CollectionAssert.AreEqual(new List<string>() { "1","2","3","4" }, OrderCalculator.getFirstPart(test2));
            CollectionAssert.AreEqual(new List<string>() { }, OrderCalculator.getFirstPart(test3));
            CollectionAssert.AreEqual(new List<string>() { "1" }, OrderCalculator.getFirstPart(test4));
        }

        //Tests the getRestOfParts method
        [TestMethod]
        public void getRestOfPartsTest()
        {
            List<string> test1 = new List<string>() { "1", "", "3", "4", "5" };
            List<string> test2 = new List<string>() { "1", "2", "3", "4", "" };
            List<string> test3 = new List<string>() { "", "2", "3", "4", "5" };
            List<string> test4 = new List<string>() { "1", "", "3", "", "5" };

            CollectionAssert.AreEqual(new List<string>() { "3","4","5" }, OrderCalculator.getRestOfParts(test1));
            CollectionAssert.AreEqual(new List<string>() { }, OrderCalculator.getRestOfParts(test2));
            CollectionAssert.AreEqual(new List<string>() { "2", "3", "4", "5" }, OrderCalculator.getRestOfParts(test3));
            CollectionAssert.AreEqual(new List<string>() { "3", "", "5" }, OrderCalculator.getRestOfParts(test4));
        }       
    }  
}
