﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Cryptography;
using System.IO;
using mealOrderCalculators;

namespace mealOrderCalculatorTest
{
    //Unit Testing for Order class
    [TestClass]
    public class OrderTest
    {

        //test the class constructor that takes a list<string> as its only input parameter
        [TestMethod]
        public void testConstructor()
        {
            List<MealTypeOrder> mealTypeOrders = new List<MealTypeOrder>();
            MealTypeOrder mealTypeOrder1 = new MealTypeOrder("Vegetarian", 5);
            MealTypeOrder mealTypeOrder2 = new MealTypeOrder("Gluten free", 7);
            mealTypeOrders.Add(mealTypeOrder1);
            mealTypeOrders.Add(mealTypeOrder2);

            Order order2 = new Order(mealTypeOrders, 50);

            List <string> input = new List<string>(){ "Order", "Total:50", "Vegetarian:5", "Gluten free:7" };

            Order order1 = new Order(input);

            Assert.AreEqual(50, order1.getTotalOrders());
            Assert.AreEqual(5, order1.getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", order1.getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(7, order1.getOrders().ElementAt(1).getQuantity());
            Assert.AreEqual("Gluten free", order1.getOrders().ElementAt(1).getMealType());
        }
    }
    
}
