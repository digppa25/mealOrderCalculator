﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Cryptography;
using System.IO;
using mealOrderCalculators;

namespace mealOrderCalculatorTest
{
    //Unit Testing for Restaurant class
    [TestClass]
    public class RestaurantTest
    {
        //test the class constructor that takes a list<string> as its only input parameter
        [TestMethod]
        public void testConstructor()
        {
            List<string> input = new List<string>() { "Restaurant B", "Rating:3/5", "Total:100", "Vegetarian:20", "Gluten free:10"};

            Restaurant restaurant = new Restaurant(input);

            Assert.AreEqual("Restaurant B", restaurant.getName());
            Assert.AreEqual(0.6, restaurant.getRating());
            Assert.AreEqual(100, restaurant.getAvailableOrders());
            Assert.AreEqual(100, restaurant.getRemainingOrders());
            Assert.AreEqual(20, restaurant.getOrders().ElementAt(0).getQuantity());
            Assert.AreEqual("Vegetarian", restaurant.getOrders().ElementAt(0).getMealType());
            Assert.AreEqual(10, restaurant.getOrders().ElementAt(1).getQuantity());
            Assert.AreEqual("Gluten free", restaurant.getOrders().ElementAt(1).getMealType());
        }

        //Test the CompareTo method that the class uses for sorting
        [TestMethod]
        public void testCompareTo()
        {
            List<string> input1 = new List<string>() { "Restaurant B", "Rating:3/5", "Total:100"};
            List<string> input2 = new List<string>() { "Restaurant A", "Rating:5/5", "Total:100"};
            List<string> input3 = new List<string>() { "Restaurant C", "Rating:5/5", "Total:110" };
            List<string> input4 = new List<string>() { "Restaurant D", "Rating:3/5", "Total:100" };

            Restaurant restaurant1 = new Restaurant(input1);
            Restaurant restaurant2 = new Restaurant(input2);
            Restaurant restaurant3 = new Restaurant(input3);
            Restaurant restaurant4 = new Restaurant(input4);

            Assert.AreEqual(1, restaurant1.CompareTo(restaurant2));
            Assert.AreEqual(-1, restaurant2.CompareTo(restaurant1));
            Assert.AreEqual(0, restaurant1.CompareTo(restaurant4));
            Assert.AreEqual(1, restaurant2.CompareTo(restaurant3));
            Assert.AreEqual(-1, restaurant3.CompareTo(restaurant2));
        }
    }

}
