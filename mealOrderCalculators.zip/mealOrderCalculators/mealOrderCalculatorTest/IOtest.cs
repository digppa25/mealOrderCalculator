﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Security.Cryptography;
using System.IO;
using mealOrderCalculators;

namespace mealOrderCalculatorTest
{
    //Unit Testing for FileIO class
    [TestClass]
    public class IOtest
    {
        //Tests the read and write methods to a text file
        [TestMethod]
        public void readWriteText()
        {
            FileIO fileio = new FileIO();
            fileio.writeFile(fileio.readFile(@"..\..\..\mealOrderCalculators\test.txt"), @"..\..\..\mealOrderCalculators\test.txt");

            string originalText = System.IO.File.ReadAllText(@"..\..\..\mealOrderCalculators\test.txt").Trim();
            string newText = System.IO.File.ReadAllText(@"..\..\..\mealOrderCalculators\test.txt.out").Trim();

            Assert.AreEqual(originalText, newText);
        }
    }
}

